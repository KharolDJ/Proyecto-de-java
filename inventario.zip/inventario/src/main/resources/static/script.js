document.addEventListener("DOMContentLoaded", () => {
    // Pantalla de bienvenida
    const welcomeScreen = document.getElementById("welcome-screen");
    if (welcomeScreen) {
        welcomeScreen.addEventListener("click", () => {
            welcomeScreen.classList.add("hidden");
            setTimeout(() => welcomeScreen.remove(), 600);
        });
    }

    // Transición entre formularios
    const container = document.querySelector(".container");
    const toggleButtons = document.querySelectorAll(".toggle-btn");
    const welcomeAdmin = document.querySelector(".welcome-admin");
    const welcomeEmployee = document.querySelector(".welcome-employee");

    toggleButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
            const target = btn.dataset.target;
            if (target === "admin") {
                container.classList.add("toggle");
                welcomeAdmin.classList.remove("active");
                welcomeEmployee.classList.add("active");
            } else if (target === "empleado") {
                container.classList.remove("toggle");
                welcomeEmployee.classList.remove("active");
                welcomeAdmin.classList.add("active");
            }
        });
    });

    // Mostrar y desaparecer mensaje de error rápido
	const errorDiv = document.getElementById("errorMessage");
	if (errorDiv) {
	    const message = errorDiv.dataset.error || "Usuario o contraseña incorrectos";
	    Swal.fire({
	        icon: "error",
	        title: "Acceso denegado",
	        text: message,
	        confirmButtonText: "Intentar de nuevo",
	        confirmButtonColor: "#3AB397",
	        background: "#fefefe",
	        timer: 3000,
	        timerProgressBar: true
	    });
	}
});
