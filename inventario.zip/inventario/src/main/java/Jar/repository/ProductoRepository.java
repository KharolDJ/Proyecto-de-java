package Jar.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import Jar.entity.Producto;
import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    List<Producto> findByNombreContainingIgnoreCaseOrDescripcionContainingIgnoreCase(String nombre, String descripcion);
    List<Producto> findByStockLessThanEqual(int stock);
    List<Producto> findByStockGreaterThan(int stock);
}
