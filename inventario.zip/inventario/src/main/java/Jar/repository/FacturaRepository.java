package Jar.repository;

import Jar.entity.Factura;
import Jar.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FacturaRepository extends JpaRepository<Factura, Integer> {
    List<Factura> findByUsuario(Usuario usuario);
}
