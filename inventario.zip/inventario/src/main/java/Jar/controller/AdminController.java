package Jar.controller;

import Jar.entity.Producto;
import Jar.repository.ProductoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final ProductoRepository productoRepository;

    public AdminController(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    @GetMapping
    public String panelAdmin(Model model) {
        model.addAttribute("productos", productoRepository.findAll());
        return "admin";
    }

    @GetMapping("/buscar")
    public String buscar(@RequestParam("q") String query, Model model) {
        List<Producto> resultados = productoRepository
                .findByNombreContainingIgnoreCaseOrDescripcionContainingIgnoreCase(query, query);
        model.addAttribute("productos", resultados);
        return "admin";
    }

    @GetMapping("/bajo-stock")
    public String verBajoStock(Model model) {
        List<Producto> bajoStock = productoRepository.findAll()
                .stream()
                .filter(p -> p.getStock() <= 5)
                .toList();

        model.addAttribute("productos", bajoStock);
        model.addAttribute("bajoStock", bajoStock);
        return "admin";
    }
    @GetMapping("/nuevo")
    public String nuevoProducto(Model model) {
        model.addAttribute("producto", new Producto());
        return "admin_form";
    }

    @PostMapping("/guardar")
    public String guardarProducto(@ModelAttribute Producto producto) {
        productoRepository.save(producto);
        return "redirect:/admin";
    }

    @GetMapping("/editar/{id}")
    public String editarProducto(@PathVariable Integer id, Model model) {
        Producto producto = productoRepository.findById(id).orElse(null);
        model.addAttribute("producto", producto);
        return "admin_form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarProducto(@PathVariable Integer id) {
        productoRepository.deleteById(id);
        return "redirect:/admin";
    }
}
