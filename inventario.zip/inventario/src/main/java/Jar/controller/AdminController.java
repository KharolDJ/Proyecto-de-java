package Jar.controller;

import Jar.entity.Producto;
import Jar.repository.ProductoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final ProductoRepository productoRepository;

    public AdminController(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    // 🔹 Panel principal del administrador
    @GetMapping
    public String panelAdmin(Model model) {
        List<Producto> productos = productoRepository.findAll();

        // Detectar productos con bajo stock
        List<Producto> bajoStock = productos.stream()
                .filter(p -> p.getStock() <= 5)
                .toList();

        model.addAttribute("productos", productos);
        model.addAttribute("bajoStock", bajoStock); // ✅ siempre presente para evitar errores Thymeleaf
        return "admin";
    }

    // 🔹 Buscar productos
    @GetMapping("/buscar")
    public String buscar(@RequestParam("q") String query, Model model) {
        List<Producto> resultados = productoRepository
                .findByNombreContainingIgnoreCaseOrDescripcionContainingIgnoreCase(query, query);

        List<Producto> bajoStock = productoRepository.findAll().stream()
                .filter(p -> p.getStock() <= 5)
                .toList();

        model.addAttribute("productos", resultados);
        model.addAttribute("bajoStock", bajoStock);
        return "admin";
    }

    // 🔹 Ver solo productos con bajo stock
    @GetMapping("/bajo-stock")
    public String verBajoStock(Model model) {
        List<Producto> bajoStock = productoRepository.findAll()
                .stream()
                .filter(p -> p.getStock() <= 5)
                .toList();

        model.addAttribute("productos", bajoStock);
        model.addAttribute("bajoStock", bajoStock);
        return "admin";
    }

    // 🔹 Crear nuevo producto
    @GetMapping("/nuevo")
    public String nuevoProducto(Model model) {
        model.addAttribute("producto", new Producto());
        return "admin_form";
    }

    // 🔹 Guardar producto (nuevo o editado)
    @PostMapping("/guardar")
    public String guardarProducto(@ModelAttribute Producto producto) {
        productoRepository.save(producto);
        return "redirect:/admin";
    }

    // 🔹 Editar producto existente
    @GetMapping("/editar/{id}")
    public String editarProducto(@PathVariable Integer id, Model model) {
        Producto producto = productoRepository.findById(id).orElse(null);
        model.addAttribute("producto", producto);
        return "admin_form";
    }

    // 🔹 Eliminar producto
    @GetMapping("/eliminar/{id}")
    public String eliminarProducto(@PathVariable Integer id) {
        productoRepository.deleteById(id);
        return "redirect:/admin?exito=true"; // ✅ muestra mensaje de éxito en el HTML
    }
}
