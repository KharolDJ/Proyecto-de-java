package Jar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        Model model) {
        if (error != null) {
            // Mensaje que se mostrará en la vista
            model.addAttribute("errorMessage", "Usuario o contraseña incorrectos, o acceso denegado para este formulario.");
        }
        return "login"; // Thymeleaf mostrará la alerta si errorMessage existe
    }

    @GetMapping("/redireccion")
    public String redireccion() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String rol = auth.getAuthorities().toString();

        if (rol.contains("ADMINISTRADOR")) {
            return "redirect:/admin";
        } else if (rol.contains("EMPLEADO")) {
            return "redirect:/empleado";
        } else {
            return "redirect:/login?error=true"; // Redirige con error si no coincide el rol
        }
    }
}
