package Jar.controller;

import Jar.entity.*;
import Jar.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;
import java.util.*;

@Controller
@RequestMapping("/empleado")
public class EmpleadoController {

    private final ProductoRepository productoRepository;
    private final UsuarioRepository usuarioRepository;
    private final FacturaRepository facturaRepository;
    private final DetalleFacturaRepository detalleFacturaRepository;

    public EmpleadoController(ProductoRepository productoRepository,
                              UsuarioRepository usuarioRepository,
                              FacturaRepository facturaRepository,
                              DetalleFacturaRepository detalleFacturaRepository) {
        this.productoRepository = productoRepository;
        this.usuarioRepository = usuarioRepository;
        this.facturaRepository = facturaRepository;
        this.detalleFacturaRepository = detalleFacturaRepository;
    }

    @GetMapping
    public String verProductos(Model model) {
        model.addAttribute("productos", productoRepository.findAll());
        return "empleado";
    }

    @GetMapping("/facturar")
    public String facturar(Model model) {
        model.addAttribute("productos", productoRepository.findAll());
        return "facturar";
    }

    @PostMapping("/facturar")
    public String procesarFactura(
            @RequestParam(value = "productoId", required = false) List<Integer> ids,
            @RequestParam(value = "cantidad", required = false) List<Integer> cantidades,
            Model model,
            Authentication authentication) {

        // 1️⃣ Validar selección
        if (ids == null || ids.isEmpty()) {
            model.addAttribute("error", "⚠ Debes seleccionar al menos un producto antes de facturar.");
            model.addAttribute("productos", productoRepository.findAll());
            return "facturar";
        }

        double total = 0;
        List<DetalleFactura> detalles = new ArrayList<>();

        // 2️⃣ Obtener usuario actual
        String username = authentication.getName();
        Usuario usuario = usuarioRepository.findByUsuario(username);

        // 3️⃣ Crear factura (aún sin guardar)
        Factura factura = new Factura();
        factura.setUsuario(usuario);

        // 4️⃣ Validar y procesar productos seleccionados
        for (int i = 0; i < ids.size(); i++) {
            Integer idProducto = ids.get(i);
            Producto producto = productoRepository.findById(idProducto).orElse(null);
            if (producto == null) continue;

            int cantidad = 1;
            if (cantidades != null && i < cantidades.size()) {
                cantidad = Math.max(1, cantidades.get(i)); // evita 0 o negativos
            }

            // 🚫 Verificar stock insuficiente
            if (producto.getStock() < cantidad) {
                model.addAttribute("error",
                        "❌ No hay suficiente stock para el producto '" + producto.getNombre() +
                        "'. Stock disponible: " + producto.getStock());
                model.addAttribute("productos", productoRepository.findAll());
                return "facturar";
            }

            // Calcular subtotal
            double subtotal = producto.getPrecio() * cantidad;
            total += subtotal;

            // Descontar del stock
            producto.setStock(producto.getStock() - cantidad);
            productoRepository.save(producto);

            // Crear detalle
            DetalleFactura detalle = new DetalleFactura();
            detalle.setFactura(factura);
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setSubtotal(subtotal);
            detalles.add(detalle);
        }

        // 5️⃣ Guardar factura
        factura.setTotal(total);
        factura.setDetalles(detalles);
        facturaRepository.save(factura);

        // 6️⃣ Enviar datos a la vista
        model.addAttribute("total", total);
        model.addAttribute("factura", factura);
        return "total";
    }

    @GetMapping("/historial")
    public String verHistorial(Model model, Authentication authentication) {
        String username = authentication.getName();
        Usuario usuario = usuarioRepository.findByUsuario(username);

        List<Factura> facturas = facturaRepository.findByUsuario(usuario);
        Map<Integer, List<DetalleFactura>> detallesPorFactura = new HashMap<>();

        for (Factura f : facturas) {
            List<DetalleFactura> detalles = detalleFacturaRepository.findByFactura(f);
            detallesPorFactura.put(f.getId_factura(), detalles);
        }

        model.addAttribute("facturas", facturas);
        model.addAttribute("detallesPorFactura", detallesPorFactura);
        return "historial";
    }

}
