package Jar.security;

import Jar.entity.Usuario;
import Jar.repository.UsuarioRepository;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Collections;

public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final UsuarioRepository usuarioRepository;
    private final HttpServletRequest request; // Para leer el campo "tipo"

    public CustomAuthenticationProvider(UsuarioRepository usuarioRepository, HttpServletRequest request) {
        this.usuarioRepository = usuarioRepository;
        this.request = request;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        // Obtener tipo de usuario desde el formulario
        String tipoFormulario = request.getParameter("tipo");

        Usuario usuario = usuarioRepository.findByUsuario(username);
        if (usuario == null || !usuario.getContrasena().equals(password)) {
            throw new BadCredentialsException("Usuario o contraseña incorrectos");
        }

        // Validar rol según el formulario
        if (!usuario.getRol().equalsIgnoreCase(tipoFormulario)) {
            throw new BadCredentialsException("Acceso denegado para este formulario");
        }

        return new UsernamePasswordAuthenticationToken(
                username,
                password,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + usuario.getRol().toUpperCase()))
        );
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
